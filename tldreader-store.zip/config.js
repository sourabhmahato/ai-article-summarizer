/**
 * Default configuration for TL;DReader.
 * Users set their own API key via Settings.
 */
const CONFIG = {
  DEFAULT_PROVIDER: "groq",
  DEFAULT_GROQ_KEY: "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",
};
